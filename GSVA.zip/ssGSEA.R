library(optparse)
option_list <- list(
  make_option(c("-i", "--infile"), type = "character", default = '/pub1/data/mg_projects/projects/web_script/tool_runing/48d62680c879ba86522cfdfa2c641491/input.json',
              action = "store", help = "Input a exp file path!"
  ),
  make_option(c("-o", "--outfile"), type = "character", default = '/pub1/data/mg_projects/projects/web_script/tool_runing/b5d509f2ddaf74dd2ca07303a86e46a3',
              action = "store", help = "Input a outfolder path!"
  )
)
logs=c()
#stx=rbind()
tryCatch({
  Args <- commandArgs()
  opt = parse_args(OptionParser(option_list = option_list, usage = "Data press"))
  #logs=c(logs,paste0('geting data:',paste0(paste0(names(opt),'=',opt),collapse = ',')))
  logs=c(logs,paste0('run ssGSEA.R-',basename(opt$outfile)))
  #library("rjson")
  library(jsonlite)
  data<-jsonlite::stream_in(file(opt$infile),pagesize = 1000)
  
  exp_path=unlist(data$exp_path)
  
  #exp_path='/pub1/data/mg_projects/projects/web_script/tool_runing/test_data/GSE73452.txt'
  #dbPath='/pub1/data/mg_projects/projects/web_script/source'
  #dbName='c2.cp.kegg.v7.4.symbols.gmt'
  #####Example 1######
  #exp_path='/pub1/data/mg_projects/projects/web_script/tool_runing/test_data/GSE73452.txt'
  #dbPath='/pub1/data/mg_projects/projects/web_script/source'
  #dbName='c2.cp.kegg.v7.4.symbols.gmt'
  #outFolder='/pub1/data/mg_projects/projects/web_script/tool_runing/test_data/GSEA'
  ###########

  dbName=unlist(data$dbMode)
  dbPath=unlist(data$dbPath)
  gmtNames=unlist(data$gmtNames)
  gmtGenes=unlist(data$gmtGenes)
  method=unlist(data$method)#c("gsva", "ssgsea", "zscore", "plage"),
  outFolder=opt$outfile
  
  nxt=TRUE
  dat=data.table::fread(exp_path, sep = "\t",header = T,stringsAsFactors = F,check.names = F
                        ,na.strings="NA",data.table = F)  
  row.names(dat)=dat[,1]
  dat=dat[,-1]  
  logs=c(logs,paste0('readed data:col=',ncol(dat),',row=',nrow(dat)))
  all.genes=row.names(dat)

  gmt_path=paste0(dbPath,'/',dbName)
  
  #outFolder='/pub1/data/mg_projects/projects/web_script/tool_runing/test_data/GSEA'
  
  if(nxt){
    if(dbName=='Custom'){
      logs=c(logs,'outputing custom gmt')
      all.list=list()
      gmt_path=paste0(outFolder,'/',dbName,'.gmt')
      for(gn in unique(gmtNames)){
        t_inds=which(gmtNames==gn)
        gens=intersect(unique(gmtGenes[t_inds]),all.genes)
        if(length(gens)>5){
          gs=GSEABase::GeneSet(setName=gn, setIdentifier=paste0("101")
                               ,geneIds=gens
                               ,GSEABase::SymbolIdentifier()) 
          all.list=c(all.list,list(gs))
        }else{
          logs=c(logs,paste0('remove ',gn,' in gmt,gene<5'))
        }
      }
      if(length(all.list)>0){
        gsc <- GSEABase::GeneSetCollection(all.list)
        GSEABase::toGmt(gsc, gmt_path)
        logs=c(logs,'outputed Custom.gmt')
      }else{
        nxt=FALSE
        logs=c(logs,'#Gene not found!')
        logs=c(logs,'#Stop:remove all Custom GMT!')
      }
    }else{
      gmt=clusterProfiler::read.gmt(gmt_path)
      gmt=gmt[gmt[,2]%in%all.genes,]
      if(sum(table(gmt[,1])>5)==0){
        nxt=FALSE
        logs=c(logs,'#Gene not found!')
        logs=c(logs,'#Stop:remove all GMT!')
      }
    }
  }
  
  if(nxt){
    logs=c(logs,'reading gmt!')
    cgeneset=GSEABase::getGmt(gmt_path)
    logs=c(logs,'runing gsva!')
    ssGSEA.geneset <- GSVA::gsva(as.matrix(dat), cgeneset,method=method,#c("gsva", "ssgsea", "zscore", "plage")
                                 min.sz=1, max.sz=5000, verbose=TRUE)
    logs=c(logs,'output gsva result!')
    prex='';
    if(dbName=='c2.cp.biocarta.v7.4.symbols.gmt') prex='BIOCARTA_';
    if(dbName=='c2.cp.kegg.v7.4.symbols.gmt') prex='KEGG_';
    if(dbName=='c2.cp.pid.v7.4.symbols.gmt') prex='PID_';
    if(dbName=='c2.cp.reactome.v7.4.symbols.gmt') prex='REACTOME_';
    if(dbName=='c2.cp.wikipathways.v7.4.symbols.gmt') prex='WP_';
    if(dbName=='c4.cm.v7.4.symbols.gmt') prex='MODULE_';
    if(dbName=='c5.go.bp.v7.4.symbols.gmt') prex='GOBP_';
    if(dbName=='c5.go.cc.v7.4.symbols.gmt') prex='GOCC_';
    if(dbName=='c5.go.mf.v7.4.symbols.gmt') prex='GOMF_';
    if(dbName=='c5.hpo.v7.4.symbols.gmt') prex='HP_';
    if(dbName=='h.all.v7.4.symbols.gmt') prex='HALLMARK_';
    if(prex!=''){
      row.names(ssGSEA.geneset)=gsub(paste0('^',prex),'',row.names(ssGSEA.geneset))
    }
    write.table(cbind(Tag=row.names(ssGSEA.geneset),ssGSEA.geneset)
                ,file = paste0(opt$outfile,'/enrichScore.txt'),quote = F,row.names = F,col.names = T,sep = '\t')
    logs=c(logs,'output succ!')
  }
},error = function(e) {
  print(conditionMessage(e))
  logs=c(logs,paste0('error:',conditionMessage(e)))
}, finally = {
  write.table(logs,file = paste0(opt$outfile,'/run.log'),quote = F,row.names = T,col.names = T,sep = '\t')
})

#library(ggstatsplot)
